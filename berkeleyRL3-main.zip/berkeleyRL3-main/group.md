# Trabalho 4 - Grupo 16 T2+

## Integrantes

**Eduardo Fantini**        - *00313339* - turma B

**João Gabreil Zandoná**   - *00314256* - turma B

**Jordi Pujol Ricarte**    - *00316161* - turma B

**Letícia Cattai Contino** - *00316207* - turma A